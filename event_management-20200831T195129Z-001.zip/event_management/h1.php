<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<style>
.top
{
	font-size:40px;
	color:blue;
}
.linktext
{
	text-decoration:none;
	color:blue;
	font-size:20px;
}
.mtxt
{
	color:white;
	font-size:50px;
}
</style>
</head>

<body>
<table style="width:1366px;">
<tr style= "height:200px;" >
<td style=" width:250px;" background="images for event management project/sastralogo.png"></td>
<td class="top">Sastra Deemed to be University</td>
</tr>
</table>

<table>
<tr > 
<td  align="center" style="width:150px;"><a class="linktext" href="home.php">ABOUT</a></td>
<td align="center" style="width:150px;"><a class="linktext" href="login_page.php">STUDENT</a></td>
<td align="center" style="width:150px;"><a class="linktext" href="volunteer_registration.php">VOLUNTEER</a></td>
<td align="center" style="width:150px;"><a class="linktext" href="facultyreg.php">Faculty</a></td>
<td align="center" style="width:150px;"><a class="linktext" href="login_page.php">ADMIN</a></td>
<td align="center" style="width:150px;"><a class="linktext" href="contact.php">CONTACT US</a></td>

</tr>
</table>
<table style=" height:500px; width:1366px; background-image:url(images%20for%20event%20management%20project/marcus-neto-96651-unsplash.jpg); opacity:0.8; background-size:1366px 800px ">
<tr>
<td align="center" class="mtxt">Cultural Event Management System </td>
<td height="500px;"></td>
</tr>
</table>
</body>
</html>