<html>
<head>
<style>
.heading1,.head{
	background-color:#D68910;
	color:white;
	font-size:50px;
	height:70px;
}
.row_user
{
	background-color:black;
	height:40px;
}
.user_name
{
	color:white;
	font-size:25px;
	font-family:Sans serifs;
}
.logoutbtn
{
	border-radius:50%;
	height:100px;
	width:100px;
	outline:0px;
	font-size:18px;
	font-style:times new roman;
}
.btn{
	width:150px;
	outline:0;
	border-radius:20px;
	padding:10px;
	border-spacing:30px;
	border:2px solid black;
	background-color:transparent;
	color:black;
}
.btn:hover
{
	background-color:rgba(0,0,0,0.5);
	opacity:1.5;
	color:white;
	border:white;
}


.dd_register_number
{
	width:180px;
	height:25px;
}
.tb{
	width:180px;
	height:25px;
}

.heading2{
	font-size:20px;
}

</style>

</head>


<?php



$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}
if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}

session_start();
$user = $_SESSION["mail_id"];



$result = mysqli_query($con," select name,register_number,mail_id,event_name from volunteer_registration where mail_id = '".$_SESSION["mail_id"]."' ");
if (!$result) {
    echo 'Could not run query: ' . $con->error;
   
	
}
$row = mysqli_fetch_row($result);
//echo 'This is your name :' .$row[0];
//echo 'This is your name :' .$row[1];
?>


<body>
<form action="" method="post">
<table  style="width:1366px; background-color:#D68910;">
<tr class="head">
<td colspan="2" ><label class="heading1">Entry Card For Participants</label></td>
</tr>
<tr class="row_user">
<td align="right" ><label class="user_name"><?php echo $row[0]; ?>                    <button  name="logout" class="logoutbtn">Log Out</button></label></td>
</form>

</tr>
<tr>
</table>

<form action="" method="post">
<table class="table1" align="center" border="1px;">
<tr>
<td align="center" colspan="5"><label class="heading2"><?php echo $row[3]; ?> Selected List</label></td>

</tr>

<tr>
<th>S No</th>
<th>Name</th>
<th>Register Number</th>
<th>Mail ID</th>
<th>College Name</th>

<tr>
<?php
$sql1 = "select name,register_number,mail_id,institute_name from student_registration where event = '".$row[3]."' and access='0'";
$result1 = $con->query($sql1);

$j=1;
if ($result1->num_rows > 0) 
{
while($row1 = $result1->fetch_assoc()) 
{

        echo "<tr> <td>".$j++." </td><td> " .$row1["name"]. " </td><td> ". $row1["register_number"]. " </td><td> " . $row1["mail_id"]. "</td><td> " . $row1["institute_name"]."</td></tr>"."<br>";
    }
}
else
{
echo "<tr><td align='center' colspan='7'>"."<label>No Records Found</label>"."</td></tr>" . $con->error;
}
?>
</table>
</form>


<form method="post" action="">

<table  style="width:1366px;">
<tr>
<td>

<table style=" background-color:#D3D3D3; border-radius:20px; " cellspacing = "20px" style="cellpadding:30px;" align="center" style="width:500px;">
<tr>
<td colspan="3" align="center">
<label><h1>Seat Allocation</h1></label>
<hr/>
</td>
</tr>

<tr>
<td align="right">
<label class="registerlbl">Select Register Number</label>
</td>
<td>
:
</td>
<td>
<select class="dd_register_number" name="dd_register_number">
<option>select</option>
         <?php 
		 
         $result = mysqli_query($con,"SELECT register_number FROM student_registration where event = '".$row[3]."' and  access='0'");

         while($row = mysqli_fetch_array($result)) 
             echo "<option value='" . $row['register_number'] . "'>" . $row['register_number'] . "</option>";
         ?>
     </select>
 
</td>
</td>
</tr>

<tr>
<td align="right">
<label>Event Id</label>
</td>
<td>
:
</td>
<td>
<input class="tb" name="event_id" type="text" required  />
</td>
</tr>

<tr>
<td align="right">
<label>Floor Number</label>
</td>
<td>
:
</td>
<td>
<input class="tb" name="floor_number" type="text" required />
</td>
</tr>

<tr>
<td align="right">
<label>Room Number</label>
</td>
<td>
:
</td>
<td>
<input class="tb" name="room_number" type="text" required />
</td>
</tr>

<tr>
<td align="right">
<label>Time</label>
</td>
<td>
:
</td>
<td>
<input class="tb" name="time" type="text" required />
</td>
</tr>

<tr>
<td align="center">
<button class="btn" name="submit">Submit</button>
</td>
<td>

</td>
<td align="center">
<button class="btn" name="reset" formnovalidate>Reset</button>
</td>
</tr>
</table>

</form>
</table>

</td>
</tr>
</table>


<?php
if(isset($_POST['submit']))
{
	$register_number = $_POST['dd_register_number'];
	$event_id = $_POST['event_id'];
	$floor_number = $_POST['floor_number'];
	$room_number = $_POST['room_number'];
	$time = $_POST['time'];
	
	 $sql2 = "insert into seat_allocation (register_number,event_id,floor_number,room_number,time) values ($register_number,$event_id,$floor_number,$room_number,$time)";
	 
	 if($con->query($sql2))
	 {
		 $sql3 = "update student_registration set access='1' where register_number = '".$register_number."'";
	 
	 if($con->query($sql3))
	 {
		 echo'Data Registered';
		 header("refresh:1");
	 }
		 
	 }
	 else
	 {
		 echo '<script>alert("Failed")</script>';
	 }
	 
}

if(isset($_POST['logout']))
{
	session_destroy();
	header('Location:event_about.php');
}
if(isset($_POST['reset']))
{
	$register_number = "select";
	$event_id = "";
	$room_number = "";
	$floor_number = "";
	$time = "";
}

?>



</body>
</html>







