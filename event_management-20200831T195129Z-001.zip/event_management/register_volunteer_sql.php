<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}

if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}
else
{
	
	$name  = $_POST['name'];
	$register_number = $_POST['register_number'];
	$mail_id  = $_POST['mail_id'];
	$college_name  = $_POST['college_name'];
	$gender  = $_POST['gender'];
	$work_experience  = $_POST['work_experience'];
	$department  = $_POST['department'];
	$password  = $_POST['password'];
	$confirm_password = $_POST['confirm_password'];
	
	

	$sql = "INSERT INTO volunteer_registration (name,register_number,mail_id,college_name,gender,work_experience,department,password,access) VALUES ('$name','$register_number','$mail_id','$college_name','$gender','$work_experience','$department','$password','0')";

if($password === $confirm_password)
{
	if($con->query($sql)===true)
	//if(!mysqli_query($con,$sql))
	{
		echo 'Data Registered';
	}
	else
	{
	echo 'Data Not Registered' . $con->error;
		
	}
}
else
{
	echo "<script>alert('Password Does Not Match');</script>";
}
	
}
	header("refresh:1;url=register_page.php");
?>

</body>
</html>
