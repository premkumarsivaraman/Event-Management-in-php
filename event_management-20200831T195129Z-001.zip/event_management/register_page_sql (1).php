<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}
if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}

	$name  = $_POST['name'];
	$event  = $_POST['events'];
	$day  = $_POST['day'];
	$month  = $_POST['month'];
	$year  = $_POST['year'];
	$gender  = $_POST['gender'];
	$email_id  = $_POST['email_id'];
	$register_number  = $_POST['register_number'];
	$iname  = $_POST['iname'];
	$location  = $_POST['location'];
	$password  = $_POST['password'];
	$confirm_password = $_POST['confirm_password'];
	
	$d = $day . '/' . $month . '/' . $year;

	$sql = "INSERT INTO student_registration (name,event,date_of_birth,gender,email_id,register_number,institution_name,institute_location,password) VALUES ('$name','$event','$d','$gender','$email_id','$register_number','$iname','$location','$password')";

if($password === $confirm_password)
{
	if(!mysqli_query($con,$sql))
	{
		echo 'Data Not Registered';
	}
	else
	{
		echo 'Data Registered';
	}
}
else
{
	echo "<script>alert('Password Does Not Match');</script>";
}
	
	header("refresh:1;url=register_page.php");
?>
</body>
</html>