<?php include'admin_page.php'; ?>
<style>
th
{
color:red;
}
</style>
</head>

<body>
<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}


if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}

?>

<table style= "width:1366px;">
<tr>
<td>
<table>
<tr>
<td>
Select Event:
</td>
<td>
<form action="" method="post">
<select class="form-control" name="n">
<option>select</option>
<option>Event I</option>
<option>Event II</option>
<option>Event III</option>
     </select>



</td>
<td>
<button name="view" >View</button>
</td>
<td>
<button name="publish" >Publish</button>
</td>
<td>
<button name="stop" >Stop</button>
</td>
</tr>
</table>
</td>
</tr>
</table>

<?php

?>


<table  align="center"  cellspacing="30px" style="background-color:#D3D3D3;  border-radius:10px; >
<tr>
<td>
<table align="center" >

<tr>
<td align="center" colspan="6">
<h2>Results</h2>
</td>
</tr>

<tr>
<td colspan="6">
<hr />
</td>
</tr>
<tr>
<th>S No</th>
<th>Register Number</th>
<th>Name</th>
<th>Institute Name</th>
<th>Total</th>
</tr>

<tr>
<td colspan="6">
<hr />
</td>
</tr>

<?php

if(isset($_POST['view']))
{
$n = $_POST['n'];
$sql = "SELECT  mark_entry.register_number,student_registration.name,student_registration.institute_name,student_registration.event,mark_entry.total FROM student_registration INNER JOIN mark_entry ON mark_entry.register_number = student_registration.register_number where event='".$n."' ORDER BY total DESC ;";
$result = $con->query($sql);

if ($result->num_rows > 0) 
{
	$i=0;
while($row = $result->fetch_assoc()) 
{
        echo "<tr> <td> " .++$i. "</td> <td>" . $row["register_number"]. " </td><td> " . $row["name"]. "</td><td> " . $row["institute_name"]."</td><td>".$row["total"]."</td></tr>"."<br>";
    }
}
else
{
	echo "No Record Found". $con->error;
}
}

if(isset($_POST['publish']))
{
	$sql3 = "update mark_entry set publish='1' ";
	 
	 if($con->query($sql3))
	 {
		 echo'Published';
		 header("refresh:1");
	 }
}


if(isset($_POST['stop']))
{
	$sql3 = "update mark_entry set publish='0' ";
	 
	 if($con->query($sql3))
	 {
		 echo'Stop Publishing';
		 header("refresh:1");
	 }
}

?>
</table>
</td>
</tr>
</table>
</form>
</body>
</html>
