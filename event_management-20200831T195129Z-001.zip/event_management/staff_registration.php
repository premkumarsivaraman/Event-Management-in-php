<?php include'event_header.php'; ?>
<style>

.heading{
	font-size:50px;
    color:White;
    font-family:Times New Roman;
    padding:30px;
    background-color:rgba(0,0,0,0.5);
    border-radius:20px;
}
.b
{
	outline:none;
	border:2px solid white;
	color:black;
	font-size:20px;
	padding:50px;
	padding-bottom:20px;
	padding-top:20px;
	background-color:rgba(0,0,0,0.5);
	text-decoration:none;
	border-radius:20px;
	color:white;
	font-family:time new roman;
	
}
.b:hover
{
	background-color:rgba(0,0,0,0);
   border-color:Black;
   color:#ff4500;
}

.r,.r1
{
    border:0;
    outline:0;
    border-bottom:2px solid white;
    background:transparent;
    color:White;
    width:150px;
    font-size:18px;
    font-family:Times New Roman;
}

.r[type=text] {
  width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r[type=text]:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

.r1
{
    width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r1:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

.lbl
{
	color:white;
}
.do
{
	color:black;
	background-color:#FAFF67;
}
select:focus
{
	border-color:#ff4500;
	 width: 200px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
	
}
</style>

<body>
<form action="" method="POST">
<table background="/event_management/loading_bar/staff_registration_img.jpg" style=" width:1366px; height:600px; background-size:1366px 600px; " >



<tr>
<td width="281px" align="">
<label class="lbl">Enter Your Name</label>
</td>
<td width="281px">
<input name="name" class="r" type="text" required="required" />

</td>

<td align="center" rowspan="9"><label class="heading" >Staff Registration</label></td>

</tr>


<tr>
<td  width="181px" align="" >
<label class="lbl">Enter Your Employee Id</label>
</td>
<td  width="281px">
<input name="employee_id" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">Mail Id</label>
</td>
<td  width="281px">
<input name="email_id" class="r" type="text"  ></input>
</td>
</tr>

<tr>
<td  width="181px" align="">

<label class="lbl">Select Your Gender</label>
</td>
<td  width="281px">
<input type="radio" name="gender" value="male"><b style="color:white"> Male</b>
  <input type="radio" name="gender" value="female"><b style="color:white"> Female</b>
  <input type="radio" name="gender" value="other"><b style="color:white"> Other</b>
</td>
</tr>



<tr>
<td  width="181px" align="">
<label class="lbl">Join Year</label>
</td>
<td  width="281px">
<!--<input name="work_experience" class="r" type="text" required="required" />-->

<select name="join_year"  class="r">
<option class="do">Select</option>
<option class="do">2000</option>
<option class="do">2001</option>
<option class="do">2002</option>
<option class="do">2003</option>
<option class="do">2004</option>
<option class="do">2005</option>
<option class="do">2006</option>
<option class="do">2007</option>
<option class="do">2008</option>
<option class="do">2009</option>
<option class="do">2010</option>
<option class="do">2011</option>
<option class="do">2012</option>
<option class="do">2013</option>
<option class="do">2014</option>
<option class="do">2015</option>
<option class="do">2016</option>
<option class="do">2017</option>
<option class="do">2018</option>
<option class="do">2019</option>

</Select>

</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">Department</label>
</td>
<td  width="281px">
<!-- <input name="department" class="r" type="text" required="required" /> -->
<select name="department"  class="r">
<option class="do">Select</option>
<option class="do">Faculty of Engineeering</option>
<option class="do">Faculty of Computer Science</option>
<option class="do">Faculty of Law</option>
<option class="do">Faculty of Businness</option>
<option class="do">Faculty of Agriculture</option>

</Select>
</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">password</label>
</td>
<td  width="281px">
<input name="password" class="r1" type="password" required="required" />
</td>
</tr>

<tr>
<td   width="181px" align="">
<label class="lbl">Re-Type Password</label>
</td>
<td  width="281px">
<input name="confirm_password" class="r1" type="password" required="required"></input>
</td>
</tr>

<tr>
<td align="center"><button class="b" name="submit"  value="Register">Submit</button></td>

<td align="center">
<a class="b" href="event_about.php">Cancel</a>
</td>
</tr>
</table>
</form>

<?php
$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}


if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}


if(isset($_POST['submit']))
{
	$name = $_POST['name'];
	$employee_id = $_POST['employee_id'];
	$email_id = $_POST['email_id'];
	$gender = $_POST['gender'];
	$join_year = $_POST['join_year'];
	$department = $_POST['department'];
	$password = $_POST['password'];
	$confirm_password = $_POST['confirm_password'];
	
	if($password == $confirm_password)
	{
		$sql = "insert into staff_registration (name,employee_id,email_id,gender,join_year,department,password,access) values ('".$name."','".$employee_id."','".$email_id."','".$gender."','".$join_year."','".$department."','".$password."','0')";
		if(!mysqli_query($con,$sql))
	{
		echo 'Data Not Registered';
	}
	else
	{
		echo "<script>alert('Data Registered')</script>";
	}
}
else
{
	echo "<script>alert('Password Does Not Match');</script>";
}
	
}


?>
</body>
</html>