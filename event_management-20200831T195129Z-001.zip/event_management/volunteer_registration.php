<?php include'event_header.php'; ?>
<style>

.heading{
	font-size:50px;
    color:White;
    font-family:Times New Roman;
    padding:30px;
    background-color:rgba(0,0,0,0.5);
    border-radius:20px;
}
.b
{
	outline:none;
	border:2px solid white;
	color:black;
	font-size:20px;
	padding:50px;
	padding-bottom:20px;
	padding-top:20px;
	background-color:rgba(0,0,0,0.5);
	text-decoration:none;
	border-radius:20px;
	color:white;
	
	
}
.b:hover
{
	background-color:rgba(0,0,0,0);
   border-color:Black;
   color:#ff4500;
}

.r,.r1
{
    border:0;
    outline:0;
    border-bottom:2px solid white;
    background:transparent;
    color:White;
    width:150px;
    font-size:18px;
    font-family:Times New Roman;
}

.r[type=text] {
  width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r[type=text]:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

.r1
{
    width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r1:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

.lbl
{
	color:white;
}
</style>

<body>
<form action="register_volunteer_sql.php" method="POST">
<table background="/event_management/loading_bar/staff_registration_img.jpg" style=" width:1366px; height:600px; background-size:1366px 600px; " >



<tr>
<td width="281px" align="">
<label class="lbl">Enter Your Name</label>
</td>
<td width="281px">
<input name="name" class="r" type="text" required="required" />

</td>

<td align="center" rowspan="9"><label class="heading" >Volunteer Registration</label></td>

</tr>


<tr>
<td  width="181px" align="" >
<label class="lbl">Enter Your Register Number</label>
</td>
<td  width="281px">
<input name="register_number" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">Mail Id</label>
</td>
<td  width="281px">
<input name="mail_id" class="r" type="text"  ></input>
</td>
</tr>

<tr>
<td  width="181px" align="">

<label class="lbl">College Name</label>
</td>
<td  width="281px">
<input name="college_name" class="r" type="text"> </input>

</td>
</tr>



<tr>
<td  width="181px" align="">

<label class="lbl">Select Your Gender</label>
</td>
<td  width="281px">
<input type="radio" name="gender" value="male"><b style="color:white"> Male</b>
  <input type="radio" name="gender" value="female"><b style="color:white"> Female</b>
  <input type="radio" name="gender" value="other"><b style="color:white"> Other</b>
</td>
</tr>



<tr>
<td  width="181px" align="">
<label class="lbl">Work Experience</label>
</td>
<td  width="281px">
<input name="work_experience" class="r" type="text" required="required" />

</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">Department</label>
</td>
<td  width="281px">
<input name="department" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td  width="181px" align="">
<label class="lbl">password</label>
</td>
<td  width="281px">
<input name="password" class="r1" type="password" required="required" />
</td>
</tr>

<tr>
<td   width="181px" align="">
<label class="lbl">Re-Type Password</label>
</td>
<td  width="281px">
<input name="confirm_password" class="r1" type="password" required="required" />
</td>
</tr>

<tr>
<td align="center"><input class="b" type="submit"  value="Register"/></td>

<td align="center">
<a class="b" href="event_about.php">Cancel</a>
</td>
</tr>
</table>
</form>


</body>
</html>