
<head>
<style>
.link
{
	text-decoration:none;
	color:white;
}
.link:hover
{
	background-color:white;
	color:black;
	border-radius:40px;
	padding:10px;
}
.h{
	color:white;
	font-size:30;
	
	}
</style>
</head>
<body>


<table bgcolor="black" style="width:1366px;">
<tr>
<td width="500px;">
<img src="/event_management/loading_bar/logo_new.png" width="200px;" height="100px;" />
</td>

<td align="">
<label class="h">SASTRA DEEMED TO BE UNIVERSITY</label>
</td

</tr>
</table>
<table style = " width:1366px; background-color:#ff4500">
<td align="center" style="width:130px;">
<a class="link" href="event_about.php" >ABOUT</a>
</td>
<td align="center" style="width:160px;">
<label><a class="link" href="register_page.php" >PARTICIPANTS</a></label>
</td>

<td align="center" style="width:140px;">
<label><a class="link" href="volunteer_registration.php" >VOLUNTEER</a></label>
</td>

<td align="center" style="width:130px;">
<label><a class="link" href="staff_registration.php" >FACULTY</a></label>
</td>

<td align="center" style="width:140px;">
<label><a class="link" href="event_login.php" >LOG IN</a></label>
</td>

<td align="center" style="width:140px;">
<label><a class="link" href="admin.php" >ADMIN</a></label>
</td>
</tr>
</table>
</body>
</html>
