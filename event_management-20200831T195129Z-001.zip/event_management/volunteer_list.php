<?php include'admin_page.php'; ?>


<?php
$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}


if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}
?>
<style>
th
{
color:red;
}

</style>

<body background="images for event management project/pic4.png">

<table border="2px;" style="width:1366px;">
<tr>
<td>
<table align="center" style="width:500px;">
<tr>
<td align="center">
<label>Select Vounteer</label>
</td>
<td>
<label>Select Event</label>
</td>
</tr>
<tr>
<td align="center">
<form action="" method="post">
<select class="form-control" name="n">
<option>select</option>
         <?php 
         $result = mysqli_query($con,"SELECT register_number FROM volunteer_registration where access='0'");

         while($row = mysqli_fetch_array($result)) 
             echo "<option value='" . $row['register_number'] . "'>" . $row['register_number'] . "</option>";
         ?>
     </select>
</td>


<td>
<select name="events">
<option>select</option>
<option value="Event I">Event I</option>
<option value="Event II">Event II</option>
<option value="Event III">Event III</option>
</select>
</td>


<td>

<button name="add">ADD</button></form>
</td>
</tr>
</table>
<?php




?>
<table style="width:1366px;">

<tr>
<td>
<table align="center" cellspacing="30px" style="background-color:#D3D3D3;  border-radius:10px;">
</td>



<tr>
<td colspan="7" align="center">
<label class="head"><h2>Volunteer Unselected List</h2></label>
</td>
</tr>
<tr>
<td colspan="7">
<hr />
</td>
</tr>
<tr>

<th>S No</th>
<th>Register Number</th>
<th>Name</th>
<th>Mail ID</th>
<th>College Name</th>
<th>Work Experience</th>
<th>Department</th>


</tr>

<tr>
<td colspan="7">
<hr />
</td>
</tr>
<?php

$sql = "select register_number,name,mail_id,college_name,work_experience,department from volunteer_registration where access = '0'";
$result = $con->query($sql);

$j=1;
if ($result->num_rows > 0) 
{
while($row = $result->fetch_assoc()) 
{

        echo "<tr> <td>".$j++." </td><td> " .$row["register_number"]. " </td><td> ". $row["name"]. " </td><td> " . $row["mail_id"]. "</td><td> " . $row["college_name"]."</td><td>".$row["work_experience"]."</td><td>".$row["department"]."</td></tr>"."<br>";
    }
}
else
{
echo "<tr><td align='center' colspan='7'>"."<label>No Records Found</label>"."</td></tr>" . $con->error;
}

if(isset($_POST['add']))
{
$n = $_POST['n'];
$event_name = $_POST['events'];
$a='1';
$u = "update volunteer_registration set event_name='".$event_name."', access='1' where register_number = '".$n."'";
if($con->query($u)=== true)
{
echo'Added';
header("refresh:0");
}
else
{
echo'Not Added' . $con->error;
}

}




?>
</table>
</td>
</tr>
</table>




<table style="width:1366px;">

</tr>
<tr>
<td>

<table align="center" cellspacing="30px" style="background-color:#D3D3D3;  border-radius:10px;">
<tr>
<td colspan="8" align="center">
<label class="head"><h2>Selected Volunteer List</h2></label>
</td>
</tr>
<tr>
<td colspan="8">
<hr />
</td>
</tr>
<tr>
<th>S No</th>
<th>Register Number</th>
<th>Name</th>
<th>Mail ID</th>
<th>College Name</th>
<th>Work Experience</th>
<th>Department</th>
<th>Event Name</th>
</tr>

<tr>
<td colspan="8">
<hr />
</td>
</tr>
<?php
$sql1 = "select register_number,name,mail_id,college_name,work_experience,department,event_name from volunteer_registration where access = '1'";
$result1 = $con->query($sql1);

$i=1;
if ($result1->num_rows > 0) 
{
while($row = $result1->fetch_assoc()) 
{

        echo "<tr> <td>".$i++." </td><td> " .$row["register_number"]. " </td><td> ". $row["name"]. " </td><td> " . $row["mail_id"]. "</td><td> " . $row["college_name"]."</td><td>".$row["work_experience"]."</td><td>".$row["department"]."</td><td>". $row["event_name"]."</td></tr>"."<br>";
    }
}
else
{
echo "<tr><td align='center' colspan='8'>"."<label>No Records Found</label>"."</td></tr>";
}
?>
</table>


</td>
</tr>
</table>




</body>
</html>
