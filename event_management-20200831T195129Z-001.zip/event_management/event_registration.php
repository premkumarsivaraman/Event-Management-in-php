<?php include 'event_header.php'; ?>
<style>
.r{
	width:150px;;
}
.b
{
	outline:none;
	border:1px solid black;
	color:black;
	font-family:verdana;
	font-size:10px;
	padding:30px;
	padding-bottom:10px;
	padding-top:10px;
	background-color:grey;
	text-decoration:none;
	border-radius:20px;
	
}
</style>


<body>
<form action="register_page_sql.php" method="POST">
<table style=" width:1366px; background-color:white;" >
<tr>
<td class="heading" align="left" style=""></td>
</tr>
<tr>
<td>

<tr>
<td align="center"><h1>Registration Form</h1></td>
</tr>

<tr>
<td>

<label>Enter Your Name</label>
</td>
<td>
<input name="name" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td>
<label>Select Event</label>
</td>
<td>
<select name="events">
<option value="Event I">Event I</option>
<option value="Event II">Event II</option>
<option value="Event III">Event III</option>
</select>
</fieldset>
</td>
</tr>

<tr>
<td>
<legend><label>Select Your Date of Birth</label>
</td>
<td>
<select name="day">
<option>1</option><option>2</option><option>3</option><option>4</option>
<option>5</option><option>6</option><option>7</option><option>8</option>
<option>9</option><option>10</option><option>11</option><option>12</option>
<option>13</option><option>14</option><option>15</option><option>16</option>
<option>17</option><option>18</option><option>19</option><option>20</option>
<option>21</option><option>22</option><option>23</option><option>24</option>
<option>25</option><option>26</option><option>27</option><option>28</option>
<option>29</option><option>30</option><option>31</option>
</select>

<select name="month">
<option>Jan</option><option>Feb</option><option>Mar</option><option>Apr</option>
<option>May</option><option>Jun</option><option>Jul</option><option>Aug</option><option>Sep</option><option>Oct</option><option>Nov</option><option>Dec</option>
</select>

<select name="year">
<option>1980</option><option>1981</option><option>1982</option><option>1983</option>
<option>1984</option><option>1985</option><option>1986</option><option>1987</option><option>1988</option><option>1989</option><option>1990</option><option>1991</option>
<option>1992</option><option>1993</option><option>1994</option><option>1995</option>
<option>1996</option><option>1997</option><option>1998</option><option>1999</option><option>2000</option><option>2001</option><option>2002</option><option>2003</option>
<option>2004</option><option>2005</option><option>2006</option><option>2007</option>
<option>2008</option><option>2009</option><option>2010</option>
</select>
</td>
</tr>



<tr>
<td>
<fieldset>
<legend><label>Select Your Gender</label></legend>
<input type="radio" name="gender" value="male"> Male
  <input type="radio" name="gender" value="female"> Female
  <input type="radio" name="gender" value="other"> Other
</fieldset>
</td>
</tr>



<tr>
<td>
<fieldset>
<legend><label>Enter Your Email Id</label></legend>
<input name="email_id" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td >
<fieldset>
<legend><label>Enter Your Register Number</label></legend>
<input name="register_number" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td>
<fieldset>
<legend><label>Enter Your Institution Name</label></legend>
<input name="iname" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td>
<fieldset>
<legend><label>Location of Your Institute</label></legend>
<input name="location" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td>
<fieldset>
<legend><label>Enter Your Password</label></legend>
<input name="password" class="r" type="password" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td>
<fieldset>
<legend><label>Re-enter the Password</label></legend>
<input name="confirm_password" class="r" type="password" required="required" />
</fieldset>
</td>
</tr>
</table>



<table align="center"  style=" width:500px; height:50px;">
<tr><td align="center"><input class="b" type="submit"  value="Register"/></td>

<td align="center">
<a class="b" href="h1.php">Cancel</a>
</td>
</tr>
</table>
</td>
</tr>

</table>

</form>

<?php



?>
</body>
