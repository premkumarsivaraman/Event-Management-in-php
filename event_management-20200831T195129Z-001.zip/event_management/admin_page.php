<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style>
.h{
	color:white;
	font-size:30px;
}
.link
{
	text-decoration:none;
	color:white;
	font-size:20px;
	
	
}

.link:hover
{
	background-color:white;
	color:black;
	border-radius:40px;
	padding:10px;
}
	
.btn{
	color:black;
	border-radius:50%;
	height:70px;
	width:70px;
	outline:none;
}
.btn:hover
{
	
	
	
}	
	
</style>
</head>

<body>
<form action="" method="post">
<table bgcolor="black" style="width:1340px;">
<tr>
<td width="500px;">
<img src="/event_management/loading_bar/logo_new.png" width="200px;" height="100px;" />
</td>

<td align="">
<label class="h">SASTRA DEEMED TO BE UNIVERSITY</label>
</td

</tr>
</table>
<table style = "width:1340px; background-color:#ff4500">
<tr>
<td style="width:130px;"  align="center">
<a class="link"  href="student_list.php">Student List</a>
</td>
<td style="width:130px;"  align="center">
<a class="link" href="volunteer_list.php">Volunteer List</a>
</td>

<td style="width:130px;"  align="center">
<a class="link" href="staff_list.php">Faculty List</a>
</td>

<td  style="width:130px;"  align="center">
<a class="link" href="result.php">Result</a>
</td>



</tr>
</table>

<table style="width:1340px;">
<tr>
<td align="right" style="width:130px;" align="center">
<label>Admin</label>
<button class="btn"  name= "logout">Log Out</button>
</td>
</tr>
</table>
</form>
<?php
if(isset($_POST['logout']))
{
	session_destroy();
	header('Location:event_about.php');
}
?>

</body>
</html>