<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><h1>VOLUNTEER</h1>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<style type="text/css">
ul{
	list-style-type:none;
	margin:0;
	padding:0;
	overflow:hidden;
}
a:link,a:visited{
	display:block;
	front-weight:bold;
	color:#ffffff;
	background-color:#98bf21;
	width:120px;
	text-align:center;
	padding:4px;
	text-transform:uppercase;
	text-decoration:none;
}
a:hover,a:active{
	background-color:7A991A;
}
li{
	float:left;
	}
	</style>
	</head>
	<body background="images for event management project/volunteer.jpeg">

	<ul>
    <li><a href="#allotment">ALLOTMENT</a></li>
	<li><a href="#results">RESULTS</a></li>
	<li><a href="#pricelist">PRICELIST</a></li>
</ul>
	</body>
	</html>



