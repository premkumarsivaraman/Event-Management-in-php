<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}
if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}

	$name  = $_POST['name'];
	$mail_id  = $_POST['mail_id'];
    $collegename = $_POST['collegename'];
	//$event  = $_POST['events'];
	//$day  = $_POST['day'];
	//$month  = $_POST['month'];
	//$year  = $_POST['year'];
	$gender  = $_POST['gender'];
	//$email_id  = $_POST['email_id'];
	//$register_number  = $_POST['register_number'];
	$workexperience = $_POST['workexperience'];
	$department = $_POST['department'];
	//$iname  = $_POST['iname'];
	//$location  = $_POST['location'];
	$password  = $_POST['password'];
	$re_type password = $_POST['re_type password'];
	
	$d = $day . '/' . $month . '/' . $year;

	$sql = "INSERT INTO volunteer_registration (name,mail_id,collegename,gender,workexperience,password) VALUES ('$name','$mail_id','$collegename','$gender','$workexperience','$department','$password')";

if($password === $re_type password)
{
	if(!mysqli_query($con,$sql))
	{
		echo 'Data Not Registered';
	}
	else
	{
		echo 'Data Registered';
	}
}
else
{
	echo "<script>alert('Password Does Not Match');</script>";
}
	
	header("refresh:1;url=volunteer_registration.php");
?>
</body>
</html>
//<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
//<html xmlns="http://www.w3.org/1999/xhtml">
//<head>
//<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
//<title>Untitled Document</title>
//</head>

//<body>
//</body>
//</html>
