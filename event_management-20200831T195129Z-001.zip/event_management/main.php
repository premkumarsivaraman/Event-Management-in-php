<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<h1><center><marquee direction="right"><font color="RED">"CULTURAL EVENT MANAGEMENT SYSTEM"</font></marquee></center></
</head>

<body>
<a href="try.php">LOGIN</a>
<a href="register_page.php">STUDENT</a>
<a href="check.php">VOLUNTEER</a>
<a href="staff.php">STAFF</a>
<a href="admin.php">ADMIN</a>
</body>
</html>

