
<?php include 'event_header.php'; ?>
<body bgcolor="lightgrey">
<table style="width:1366px; height:500px; background-image:url(/event_management/loading_bar/event_about1.jpg); background-size:1366px 500px;">
<tr>
<td align="center">
<label class="topic"><h1 style="color:white;">Cultural Management System</h1></label>
</td>
</td>
</table>


<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}


if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}

$sql = "select mark_entry.register_number,mark_entry.total,student_registration.register_number from mark_entry inner join student_registration on mark_entry.register_number = student_registration.register_number where student_registration.event = 'Event I' and publish = '1' order by total desc limit 3";
$result = $con->query($sql);

if($result->num_rows > 0)
{
	echo"<h1>Event I</h1>";
	echo"<hr/>";
	echo "<table ><tr><td width='200px'>Register Number</td><td>Marks</td></tr>";
	while($row = $result->fetch_assoc()) 
{
	echo "<tr> <td>".$row["register_number"]."</td><td>".$row["total"]."</td></tr>";
}
echo"</table>";
}



$sql1 = "select mark_entry.register_number,mark_entry.total,student_registration.register_number from mark_entry inner join student_registration on mark_entry.register_number = student_registration.register_number where student_registration.event = 'Event II' and publish = '1' order by total desc limit 3";
$result1 = $con->query($sql1);

if($result1->num_rows > 0)
{
	echo"<h1>Event II</h1>";
	echo"<hr/>";
	echo "<table ><tr><td width='200px'>Register Number</td><td>Marks</td></tr>";
	while($row1 = $result1->fetch_assoc()) 
{
	echo "<tr> <td>".$row1["register_number"]."</td><td>".$row1["total"]."</td></tr>";
}
echo"</table>";
}



$sql2 = "select mark_entry.register_number,mark_entry.total,student_registration.register_number from mark_entry inner join student_registration on mark_entry.register_number = student_registration.register_number where student_registration.event = 'Event III' and publish = '1' order by total desc limit 3";
$result2 = $con->query($sql2);

if($result2->num_rows > 0)
{
	echo"<h1>Event III</h1>";
	echo"<hr/>";
	echo "<table ><tr><td width='200px'>Register Number</td><td>Marks</td></tr>";
	while($row2 = $result2->fetch_assoc()) 
{
	echo "<tr> <td>".$row2["register_number"]."</td><td>".$row2["total"]."</td></tr>";
}
echo"</table>";
}


?>
</body>
</html>