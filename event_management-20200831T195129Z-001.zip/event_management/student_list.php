<?php include'admin_page.php'; ?>
<style>
th
{
color:red;
}
</style>
</head>

<body>
<?php


$con = mysqli_connect('localhost','root','');
if(!$con)
{
	echo 'Not Connected to Database';
}


if(!mysqli_select_db($con,'event_management'))
{
	echo 'Database Not Select';
}


$sql = "select name,event,date_of_birth,gender,mail_id,register_number from student_registration";
$result = $con->query($sql);
?>
<table  align="center"  cellspacing="30px" style="background-color:#D3D3D3;  border-radius:10px; >
<tr>
<td>
<table align="center" >

<tr>
<td align="center" colspan="6">
<h2>Student Registration Records</h2>
</td>
</tr>

<tr>
<td colspan="6">
<hr />
</td>
</tr>
<tr>

<th>Name</th>
<th>Event</th>
<th>Date of Birth</th>
<th>Gender</th>
<th>Email Id</th>
<th>Register Number</th>

</tr>

<tr>
<td colspan="6">
<hr />
</td>
</tr>

<?php


if ($result->num_rows > 0) 
{
while($row = $result->fetch_assoc()) 
{
        echo "<tr> <td>" . $row["name"]. " </td><td> " . $row["event"]. "</td><td> " . $row["date_of_birth"]."</td><td>".$row["gender"]."</td><td>".$row["mail_id"]."</td><td>".$row["register_number"]."</td></tr>"."<br>";
    }
}
else
{
	echo'No Records' . $con->error;
}

?>
</table>
</td>
</tr>
</table>
</body>
</html>
