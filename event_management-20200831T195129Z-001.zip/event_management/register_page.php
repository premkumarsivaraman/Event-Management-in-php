<?php include'event_header.php'; ?>
<style>
.heading{
	font-size:50px;
    color:White;
    font-family:Times New Roman;
    padding:30px;
    background-color:rgba(0,0,0,0.5);
    border-radius:20px;
}
.r{
	width:150px;;
}
.b
{
	outline:none;
	border:2px solid white;
	color:black;
	font-size:20px;
	padding:50px;
	padding-bottom:20px;
	padding-top:20px;
	background-color:rgba(0,0,0,0.5);
	text-decoration:none;
	border-radius:20px;
	color:white;
	
	
}
.b:hover
{
	background-color:rgba(0,0,0,0);
   border-color:Black;
   color:#ff4500;
}

.r,.r1
{
    border:0;
    outline:0;
    border-bottom:2px solid black;
    background:transparent;
    color:black;
    width:150px;
    font-size:18px;
    font-family:Times New Roman;
}

.r[type=text] {
  width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r[type=text]:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

.r1
{
    width: 150px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.r1:focus {
  width:200px;
  border-bottom:2px solid #ff4500;
}

</style>

</head>

<body>
<form action="register_page_sql.php" method="POST">
<table background="/event_management/loading_bar/registration_bg.jpg"  style=" width:1366px; height:600px; background-size:1366px 600px" >

<tr>
<td align="" width="181px;">

<label>Enter Your Name</label>
</td>
<td width="281px;">
<input name="name" class="r" type="text" required="required" />

</td>

<td width="800px;"  align="center" rowspan="10"><label class="heading" >Participants Registration</label></td>
</tr>

<tr>
<td >

<label>Select Event</label>
</td>
<td>
<select style= "width:150px;" name="events">
<option value="Event I">Event I</option>
<option value="Event II">Event II</option>
<option value="Event III">Event III</option>
</select>

</td>
</tr>

<tr>
<td >

<label>Select Your Date of Birth</label>
</td>
<td>
<select name="day">
<option>1</option><option>2</option><option>3</option><option>4</option>
<option>5</option><option>6</option><option>7</option><option>8</option>
<option>9</option><option>10</option><option>11</option><option>12</option>
<option>13</option><option>14</option><option>15</option><option>16</option>
<option>17</option><option>18</option><option>19</option><option>20</option>
<option>21</option><option>22</option><option>23</option><option>24</option>
<option>25</option><option>26</option><option>27</option><option>28</option>
<option>29</option><option>30</option><option>31</option>
</select>

<select name="month">
<option>Jan</option><option>Feb</option><option>Mar</option><option>Apr</option>
<option>May</option><option>Jun</option><option>Jul</option><option>Aug</option><option>Sep</option><option>Oct</option><option>Nov</option><option>Dec</option>
</select>

<select name="year">
<option>1980</option><option>1981</option><option>1982</option><option>1983</option>
<option>1984</option><option>1985</option><option>1986</option><option>1987</option><option>1988</option><option>1989</option><option>1990</option><option>1991</option>
<option>1992</option><option>1993</option><option>1994</option><option>1995</option>
<option>1996</option><option>1997</option><option>1998</option><option>1999</option><option>2000</option><option>2001</option><option>2002</option><option>2003</option>
<option>2004</option><option>2005</option><option>2006</option><option>2007</option>
<option>2008</option><option>2009</option><option>2010</option>
</select>
</td>
</tr>



<tr>
<td >

<label>Select Your Gender</label>
</td>
<td>
<input type="radio" name="gender" value="male"> Male
  <input type="radio" name="gender" value="female"> Female
  <input type="radio" name="gender" value="other"> Other

</td>
</tr>



<tr>
<td >
<label>Enter Your Email Id</label></td>
<td>
<input name="email_id" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td>
<label>Enter Your Register Number</label>
</td>
<td>
<input name="register_number" class="r" type="text" required="required" />
</fieldset>
</td>
</tr>

<tr>
<td >
<label>Enter Your Institution Name</label>
</td>
<td>
<input name="iname" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td >

<label>Location of Your Institute</label>
</td>
<td>
<input name="location" class="r" type="text" required="required" />
</td>
</tr>

<tr>
<td >
<label>Enter Your Password</label>
</td>
<td>
<input name="password" class="r1" type="password" required="required" />
</td>
</tr>

<tr>
<td >
<label>Re-enter the Password</label>
</td>
<td>
<input name="confirm_password" class="r1" type="password" required="required" />
</td>
</tr>

<tr><td align="center"><input class="b" type="submit"  value="Register"/></td>

<td align="center">
<a class="b" href="event_about.php">Cancel</a>
</td>
</tr>

</table>
</form>

</body>



</html>


