<?php include'event_header.php';?>
<style>
.fs
{
width:400px;
color:#FFFFFF;
}
.btn
{
width:200px;
height:70px;
border-radius:30px;
color:white;
background-color:transparent;
border-color:white;
outline:0px;
}
.btn:hover
{
background-color:white;
color:black;
}
.tb
{
border:0;
border-bottom:2px solid white;	
background-color:transparent;
outline:0;
color:white;
}
.tb1
{
	border:0;
border-bottom:2px solid white;	
background-color:transparent;
outline:0;
color:white;
}
.tb:focus
{
	border-bottom:2px solid #ff4500l;
}
.tb1:focus
{
	border-bottom:2px solid #ff4500l;
}
.lbl{
	color:white;
}
</style>
</head>

<body>
<form action="" method="post">
<table  background="/event_management/loading_bar/admin_bg1.jpg" style="width:1366px; height:500px; background-size:1366px 500px;  ">
<tr>  
<td>
<table cellpadding="10" align="center" style="width:500px; ">
<tr>
<td align="center">
<label class="lbl">User Name</label>
</td>
</tr>
<tr >
<td align="center">
<input class="tb" name="email_id" type="text" />
</td>
</tr>
<tr>
<td align="center">
<label class="lbl">Password</label>
</td>
</tr>
<tr>
<td align="center">
<input class="tb1" name="password" type="password" />
</td>
</tr>
<tr>
<td align="center">
<button class="btn" name="submit" >SUBMIT</button>
</td>
</tr>
</td>
</table>
</td>
</tr>
</table>
</form>
<?php
$host = "localhost";
$user = "root";
$password = "";
$db="event_management";

$con = mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);
if(isset($_POST['submit']))
{
	$email_id = $_POST['email_id'];
	$password = $_POST['password'];
$sql = "select name,email_id,password from admin where email_id='".$email_id."' and password = '".$password."' ";
$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1)
{
session_start();
$_session['admin'] = $row[0] ;
header("location:admin_page.php");
}
	
else
{
	echo "<script>alert('email id or password is worng')</script>";
}



}

?>
</body>
</html>
