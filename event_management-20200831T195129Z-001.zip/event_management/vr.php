<?php include'event_header.php'; ?>
<style>
.i
{
width:480px;
}
.heading
{
background-color:#CC0000;
height:70px;
font-size:50px;
}
.btn
{
width:100px;
height:50px;
border-radius:30px;
outline:0px;
font-weight:bold;
background-color:#CC0000;
}
.btn:hover
{
background-color:white;
}
</style>
</head>

<body background="images for event management/glitter.gif">

<form action="" method="post">

<table style="width:1366px;">
<tr>
<td>
<table align="center" style="width:500px;">

<tr>
<td align="center" colspan="2">
<h1 class="heading">Volunteer Registration</h1>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Register Number</label></legend>
<input name="register_number" type="text" class="i"/>
</fieldset>
</td>
</tr>


<tr>
<td colspan="2">
<fieldset>
<legend><label>Name</label></legend>
<input name="name" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Mail Id</label></legend>
<input name="mail_id" type="text" class="i"/>
</fieldset>
</td>
</tr>


<tr>
<td colspan="2">
<fieldset>
<legend><label>College Name</label></legend>
<input name="college_name" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Work Experience</label></legend>
<input name="work_experience" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Department</label></legend>
<input name="department" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Password</label></legend>
<input name="password" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td colspan="2">
<fieldset>
<legend><label>Confirm Password</label></legend>
<input name="confirm_password" type="text" class="i"/>
</fieldset>
</td>
</tr>

<tr>
<td align="center">
<button class="btn" name="submit" >SUBMIT</button>
</td>
<td align="center">
<button class="btn" name="cancel">Cancel</button>
</td>
</tr>

</table>
</td>
</tr>
</table>

</form>




<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "event_management";


$con = mysqli_connect($host,$user,$password,$db);
if(!$con)
{
echo'Not Connected';
}

if(isset($_POST['submit']))
{
$register_number = $_POST['register_number'];
$name = $_POST['name'];
$mail_id = $_POST['mail_id'];
$college_name = $_POST['college_name'];
$work_experience = $_POST['work_experience'];
$department = $_POST['department'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];
$access = '0';

if($password === $confirm_password)
{
$sql = "insert into volunteer_registration (register_number,name,mail_id,college_name,work_experience,department,password,access) values('".$register_number."','".$name."','".$mail_id."','".$college_name."','".$work_experience."','".$department."','".$password."','".$access."')";


if($con->query($sql)===true)
{
echo'Records Saved Successfully';
}

else
{
echo 'Data Not Registered' . $con->error;
}

header("refresh:2");

}

if(isset($_POST['cancel']))
{
header("location:event_about.php");
}

}

?>
</body>
</html>
