<?php include 'event_header.php'; ?>
<style>
.btn{
	width:150px;
	outline:0;
	border-radius:20px;
	padding:10px;
	border-spacing:30px;
	border:2px solid white;
	background-color:transparent;
	color:white;
}
.btn:hover
{
	background-color:rgba(0,0,0,0.5);
	opacity:1.5;
}

.tb,.tbpass
{
	width:370px;
	outline:0;
	border:2px solid white;
	height:20px;
	background-color:transparent;
	color:white;
	height:35px;
	font-size:25px;
	font-family:Morris Sans;
}
.tb[type=text] {
  width: 370px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.tb[type=text]:focus {
  width:370px;
  border:2px solid #ccff00;
}

.tbpass
{
    width: 370px;
  -webkit-transition: width .35s ease-in-out;
  transition: width .35s ease-in-out;
}
.tbpass:focus {
  width:370px;
  border:2px solid #ccff00;
}

.fbtn
{
	text-decoration:none;
}
.fslogin{
	
	border-color:white;
	
}
.lbl
{
	color:white;
	font-size:17px;
}
</style>
</head>

<body background="/event_management/loading_bar/loginbg.jpg" style = "background-size:100% 100%;">

<form action="" method="post">
<table style=" width:1366px; height:400px;">

<tr>
<td>

<table align="center" style="width:400px;">
<tr>
<td colspan="2" align="center">
<label class="lbl" style="font-size:20px;">Login</label>
</td>
</tr>
<tr>
<td align="center" colspan="2">
<input type="radio" name="login" value="student_login"><label class="lbl">Student Login</label>
<input type="radio" name="login" value="volunteer_login"><label class="lbl">Volunteer Login</label>
</td>
</tr>



<tr >
<td colspan="2" >
<fieldset class="fslogin">
<legend><label class="lbl">User Name</label></legend>
<input name="username" type="text" class="tb" autocomplete="off" />
</fieldset>
</td>
</tr>


<tr >

<td colspan="2"  >
<fieldset class="fslogin">
<legend><label class="lbl">Password</label></legend>
<input name="password" class="tbpass" type="password"  />
</fieldset>
</td>
</tr>

<tr>
<td  align="center" >
<button name="sumbit" class="btn" >SUBMIT</button>
</td>

<td  align="center" >
<input type="submit" value="Sign Up" class="btn" name ="signup"/>
</td>
</tr>
<tr>
<td colspan="2" align="center" >
<a class="fbtn" href="" >Forgot Password ?</a>
</td>

</tr>
</table>

</td>
</tr>

</table>
</form>

<?php

$host = "localhost";
$user = "root";
$password = "";
$db="event_management";

$con = mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);

if(isset($_POST['sumbit']))
{

if($_POST['login']==="volunteer_login")
{


	$uname = $_POST['username'];
	$passwd = $_POST['password'];
	
	$a= '1';
	$sql = "select mail_id,password from volunteer_registration where mail_id = '".$uname."' and password = '".$passwd."' and access = '".$a."' ";
	
	$result = mysqli_query($con,$sql);
	
	
	if(mysqli_num_rows($result)==1)
	{
		session_start();
		$_SESSION['mail_id'] = $uname;
		
		echo 'Login Successfully'.$_SESSION["mail_id"];
		header("Location:volunteer_entry.php");
		
		
		
		
	}
	else
	{
		echo 'Login Failed' . $con->error;
		
	}
	
}
else if($_POST['login']==="student_login")
{
$uname = $_POST['username'];
$password = $_POST['password'];

$sql1 = "select mail_id,password from student_registration where mail_id='".$uname."' and password='".$password."' ";

$result1 = mysqli_query($con,$sql1);

if(mysqli_num_rows($result1)==1)
{
		session_start();
		$_SESSION['mail_id'] = $uname;
		header("Location:student_entry.php");
		
}

	
}



}


if(isset($_POST['signup']))
{
	header("Location:register_page.php");
}
?>
</body>
</html>