<html>
<head>
<style>
.process_updating
{
	font-size:30px;
	color:red;
}
.h{
	color:white;
	font-size:30;
	
	}
	.heading1,.head{
	background-color:#D68910;
	color:white;
	font-size:30px;
	height:70px;
}
.row_user
{
	background-color:black;
	height:40px;
}
.user_name
{
	color:white;
	font-size:25px;
	font-family:Sans serifs;
}
.logoutbtn
{
	border-radius:50%;
	height:100px;
	width:100px;
	outline:0px;
	font-size:18px;
	font-style:times new roman;
}
.dd_register_number
{
	width:150px;
}
.heading2{
	font-size:20px;
}
</style>


</head>

<body>
<?php 
session_start(); 

$host = "localhost";
$user = "root";
$password = "";
$db="event_management";

$con = mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);

$sql1 = "select student_registration.name,student_registration.register_number,student_registration.event,seat_allocation.event_id,seat_allocation.floor_number,seat_allocation.room_number,seat_allocation.time from student_registration inner join seat_allocation on student_registration.register_number = seat_allocation.register_number where student_registration.mail_id = '".$_SESSION['mail_id']."' and student_registration.access = '1' ";
$result1 = mysqli_query($con,$sql1);
if(!$result1)
{
	echo 'not executed' . $con->error;
}

$row1 = mysqli_fetch_row($result1);

?>
<table bgcolor="black" style="width:1366px;">
<tr>
<td>
<img src="/event_management/loading_bar/logo_new.png" width="200px;" height="100px;" />
</td>

<td align="">
<label class="h">SASTRA DEEMED TO BE UNIVERSITY</label>
</td

</tr>
</table>







<table  style="width:1366px; background-color:#D68910;">
<tr class="head">
<td colspan="2" ><label class="heading1">Welcome<label style="color:;"> <?php echo $row1[0]; ?> </label>  this is your Seat Allocation</label></td>
</tr>
</table>
<form action="" method="post">
<table style="width:1366px;">
<tr class="row_user">
<td align="right" ><label class="user_name"><?php echo $row1[0]; ?>                  <button  name="logout" class="logoutbtn">Log Out</button></label></td>
</td>
</tr>
</table>

</form>





<?php
$sql2 = "select access from student_registration where mail_id = '".$_SESSION['mail_id']."' ";
$result2 = mysqli_query($con,$sql2);
if(!$result2)
{
	echo 'not executed' . $con->error;
}

$row2 = mysqli_fetch_row($result2);

if($row2[0]==0)
{
?>
<table align="center">
<tr>
<td>
<img src="/event_management/loading_bar/loading.gif" alt="a">	
</td>

<td>
<label class="process_updating">Your Seat Allocation is in Progress. Please Login After Sometime</label>
</td>
</tr>
	
</table
<?php
}
else
{	
?>

<table style="width:1366px;">
<tr>
<td align="center">
	<table style=" background-color:#D3D3D3; border-radius:20px;" cellspacing="20px;">
	<tr>
	<td align="right" colspan="3">
	<input type="image" src="/event_management/loading_bar/print1.png"style="width:25px; height:25px;" onclick="window.print();" />
	</td>
	<tr>
	<td colspan="3" align="center">
	<h1>ADMIT CARD</h1>
	<hr/>
	</td>
	</tr>
	<tr>
	<td align="right">
	<label class="lbl">Name</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[0] ?></label>
	</td>
	</tr>


<tr>
	<td align="right">
	<label class="lbl">Register Number</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[1] ?></label>
	</td>
	</tr>	
	
<tr>
	<td align="right">
	<label class="lbl">Mail Id / User Name</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $_SESSION['mail_id'] ?></label>
	</td>
	</tr>	


<tr>
	<td align="right">
	<label class="lbl">Event Name</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[2] ?></label>
	</td>
	</tr>	

<tr>
	<td align="right">
	<label class="lbl">Event Id</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[3] ?></label>
	</td>
	</tr>	

<tr>
	<td align="right">
	<label class="lbl">Floor Number</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[4] ?></label>
	</td>
	</tr>	

<tr>
	<td align="right">
	<label class="lbl">Room Number</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[5] ?></label>
	</td>
	</tr>	

<tr>
	<td align="right">
	<label class="lbl">Time</label>
	</td>
	<td>:</td>
	<td>
	<label><?php echo $row1[6] ?></label>
	</td>
	</tr>	
	</table>

</td>
</tr>
</table>
	
<?php
}
?>




<?php
if(isset($_POST['logout']))
{
	session_destroy();
	header("location:event_login.php");
}
?>

</body>
</html>


